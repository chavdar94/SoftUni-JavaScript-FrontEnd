function attachElements() {
	const API_URL = 'http://localhost:3030/jsonstore/tasks/'
	const inputDOMFields = {
		name: document.getElementById('course-name'),
		type: document.getElementById('course-type'),
		description: document.getElementById('description'),
		teacherName: document.getElementById('teacher-name')
	}

	const otherDOMElements = {
		addBtn: document.getElementById('add-course'),
		editBtn: document.getElementById('edit-course'),
		courseList: document.getElementById('list'),
		loadCourses: document.getElementById('load-course')
	}

	let currentId = null

	otherDOMElements.loadCourses.addEventListener('click', loadAllCourses)
	otherDOMElements.addBtn.addEventListener('click', addNewCourseHandler)
	otherDOMElements.editBtn.addEventListener('click', editCourseHandler)

	async function loadAllCourses() {
		const response = await fetch(API_URL)
		const data = await response.json()

		for (const field in inputDOMFields) {
			inputDOMFields[field].value = ''
		}
		otherDOMElements.courseList.innerHTML = ''

		for (const key in data) {
			[name, type, description, tname, _id] = Object.values(data[key])
			const div = createElement('div', null, otherDOMElements.courseList, _id, ['container'])
			createElement('h2', name, div)
			createElement('h3', tname, div)
			createElement('h3', type, div)
			createElement('h4', description, div)

			const editCourseBtn = createElement('button', 'Edit Course', div, null, ['edit-btn'])
			const finishCourseBtn = createElement('button', 'Finish Course', div, null, ['finish-btn'])

			editCourseBtn.addEventListener('click', editCurrentCourse)
			finishCourseBtn.addEventListener('click', finishCourse)
		}
	}


	async function addNewCourseHandler(e) {
		e.preventDefault()

		const title = inputDOMFields.name.value
		const type = inputDOMFields.type.value
		const description = inputDOMFields.description.value
		const teacher = inputDOMFields.teacherName.value

		for (const field in inputDOMFields) {
			inputDOMFields[field].value = ''
		}

		const httpHeaders = {
			method: 'POST',
			body: JSON.stringify({title, type, description, teacher})
		}

		await fetch(API_URL, httpHeaders)
		await loadAllCourses()

	}

	async function editCurrentCourse(e) {
		const currentElement = e.target.parentElement
		const children = Array.from(currentElement.children)
		currentId = currentElement.id

		inputDOMFields.name.value = children[0].textContent
		inputDOMFields.type.value = children[2].textContent
		inputDOMFields.description.value = children[3].textContent
		inputDOMFields.teacherName.value = children[1].textContent

		currentElement.remove()
		otherDOMElements.addBtn.disabled = true
		otherDOMElements.editBtn.disabled = false
	}

	async function editCourseHandler(e) {
		e.preventDefault()

		const newTitle = inputDOMFields.name.value
		const newType = inputDOMFields.type.value
		const newDesc = inputDOMFields.description.value
		const newTeacher = inputDOMFields.teacherName.value

		const httpHeaders = {
			method: 'PUT',
			body: JSON.stringify({
				title: newTitle,
				type: newType,
				description: newDesc,
				teacher: newTeacher,
				_id: currentId
			})
		}

		await fetch(`${API_URL}${currentId}`, httpHeaders)
		await loadAllCourses()

		for (const field in inputDOMFields) {
			inputDOMFields[field].value = ''
		}

		otherDOMElements.addBtn.disabled = false
		otherDOMElements.editBtn.disabled = true
	}

	async function finishCourse(e) {
		currentId = e.target.parentElement.id

		const httpHeaders = {
			method: 'DELETE'
		}

		await fetch(`${API_URL}${currentId}`, httpHeaders)
		await loadAllCourses()
	}

	function createElement(type, content, parentNode, id, classes, attrs) {
		const htmlElement = document.createElement(type);

		if (content && type !== 'input') {
			htmlElement.textContent = content;
		}

		if (content && type === 'input') {
			htmlElement.value = content;
		}

		if (id) {
			htmlElement.id = id;
		}

		if (classes) {
			htmlElement.classList.add(...classes);
		}

		if (parentNode) {
			parentNode.appendChild(htmlElement);
		}

		if (attrs) {
			for (const key in attrs) {
				htmlElement.setAttribute(key, attrs[key]);
			}
		}

		return htmlElement;

	}


}

attachElements()